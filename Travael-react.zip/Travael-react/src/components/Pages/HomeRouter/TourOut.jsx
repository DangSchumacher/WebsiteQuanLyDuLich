import React from 'react'

export default function TourOut() {
  return (
    <div>TourOut</div>
  )
}
