import React from 'react'

export default function Page_404() {
  return (
    <div style={{textAlign: 'center', fontSize: '30px'}}>Page_404</div>
  )
}
